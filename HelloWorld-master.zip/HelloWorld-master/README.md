# HelloWorld
Turn Back Python 2.7

Must!! Python 2.7

Fix qr, Email

BUG : LineApi.py not update, You can update yourself

1. apt install python
2. apt install git
3. git clone https://github.com/HelloTan/HelloWorld
4. pip install requests
5. pip install rsa
6. pip install thrift==0.9.3
7. pip install bs4
8. pip install pytz
9. pip install humanfriendly
10. pip install gtts
11. pip install googletrans
12. ls
13. python self.py



Happy Play With Bot >_<


If You want ASK!

Join in square :
https://line.me/ti/g2/7k0FNnZ4b0CFtYTra58BVGtbOnLZJ4PukdMQriMlXLEQtlUs16CbDq_ej5pSGGkB
